package java_ptit;

public class INSTITUTION{
    private String vt;
    private String name;
    public INSTITUTION(String vt, String name){
        this.vt = vt;
        this.name = name;
    }
    public String getVt(){
        return vt;
    }
    public String getName(){
        return name;
    }
}