package java_ptit;
public class ICPC{
    private String name,school;
    public ICPC( String name,String school){
        this.name = name;
        this.school = school;
    }
    public String getSchool(){
        return school;
    }
    public String getName(){
        return name;
    }
    public String toString(){
        return name + " " + school;
    }
}